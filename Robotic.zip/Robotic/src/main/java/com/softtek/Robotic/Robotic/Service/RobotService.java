package com.softtek.Robotic.Robotic.Service;

import java.util.List;

import com.softtek.Robotic.Robotic.entity.Robot;

public interface RobotService {
public List<Robot> getAll();
}
