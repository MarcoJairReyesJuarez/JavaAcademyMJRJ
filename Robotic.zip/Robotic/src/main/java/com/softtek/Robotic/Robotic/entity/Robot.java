package com.softtek.Robotic.Robotic.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Productos")
public class Robot {
	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String Robot;
private String Descripcion;
private Double Precio;
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getRobot() {
	return Robot;
}
public void setRobot(String robot) {
	Robot = robot;
}
public String getDescripcion() {
	return Descripcion;
}
public void setDescripcion(String descripcion) {
	Descripcion = descripcion;
}
public Double getPrecio() {
	return Precio;
}
public void setPrecio(Double precio) {
	Precio = precio;
}
@Override
public String toString() {
	return "Robot [id=" + id + ", Robot=" + Robot + ", Descripcion=" + Descripcion + ", Precio=" + Precio + "]";
}

}
