package com.softtek.Robotic.Robotic.Service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.softtek.Robotic.Robotic.Repository.RobotRepository;
import com.softtek.Robotic.Robotic.entity.Robot;

@Service
public class RobotImplService implements RobotService {

	@Autowired
    private RobotRepository robotRepository;

 

    public static final Logger LOGGER = LoggerFactory.getLogger(RobotService.class);



	@Override
	public List<Robot> getAll() {
		List<Robot> robotList = (List<Robot>) this.robotRepository.findAll();
        LOGGER.info("## Robot Obtained: {}", robotList);
        return robotList;
	}

 
}
