package com.softtek.Robotic.Robotic.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.softtek.Robotic.Robotic.Service.RobotService;
import com.softtek.Robotic.Robotic.entity.Robot;

@RestController
public class RobotRestController {
@Autowired
RobotService robotService;

@GetMapping("/Todos")
public List<Robot> getAll(){
	return robotService.getAll();
}
}
