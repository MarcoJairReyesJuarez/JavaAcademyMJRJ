package com.softtek.Robotic.Robotic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoboticApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoboticApplication.class, args);
	}

}
