package com.softtek.Robotic.Robotic.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.softtek.Robotic.Robotic.entity.Robot;
@Repository
public interface RobotRepository extends CrudRepository<Robot, Integer>{

}
