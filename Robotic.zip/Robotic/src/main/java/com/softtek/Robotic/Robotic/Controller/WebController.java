package com.softtek.Robotic.Robotic.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.softtek.Robotic.Robotic.Service.RobotService;
import com.softtek.Robotic.Robotic.entity.Robot;

@Controller
public class WebController {
	@Autowired
	RobotService robotService;
	@GetMapping("/index")
    public String goHome(Model model) {
        List<Robot> robotList = robotService.getAll();
        model.addAttribute("robots", robotList);
        return "index";
    }

 

    @RequestMapping("/Home")
    public String home() {
        return "index";
    }

 

    @RequestMapping("/blog")
    public String blog() {
        return "blog";
    }

 

    @RequestMapping("/contact")
    public String contact() {
        return "contact";
    }
}
